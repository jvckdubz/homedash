export { default } from './PaymentsPage';
export { default as PaymentsPage } from './PaymentsPage';
